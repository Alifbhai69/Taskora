-- Taskora MVP schema. Run only in a NEW test Supabase project.
create extension if not exists pgcrypto;

create type public.app_role as enum ('worker','client','admin');
create type public.payment_method as enum ('bkash','nagad');
create type public.payment_status as enum ('pending','approved','rejected');
create type public.withdrawal_status as enum ('pending','approved_for_payout','paid','rejected');
create type public.ledger_kind as enum ('deposit','task_funding','task_reward','platform_fee','withdrawal_hold','withdrawal_paid','refund','adjustment');

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text,
 role public.app_role not null default 'worker',
 created_at timestamptz not null default now()
);
create table public.wallets (
 user_id uuid primary key references public.profiles(id) on delete cascade,
 available_paisa bigint not null default 0 check (available_paisa >= 0),
 pending_paisa bigint not null default 0 check (pending_paisa >= 0),
 updated_at timestamptz not null default now()
);
create table public.payment_requests (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 method public.payment_method not null,
 amount_paisa bigint not null check (amount_paisa > 0),
 transaction_reference text not null,
 sender_account_last4 text,
 status public.payment_status not null default 'pending',
 admin_note text,
 reviewed_by uuid references public.profiles(id),
 reviewed_at timestamptz,
 created_at timestamptz not null default now(),
 unique(method, transaction_reference)
);
create table public.ledger (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 kind public.ledger_kind not null,
 amount_paisa bigint not null check (amount_paisa > 0),
 direction text not null check (direction in ('credit','debit')),
 reference_type text not null,
 reference_id uuid not null,
 idempotency_key text not null unique,
 note text,
 created_at timestamptz not null default now()
);
create table public.withdrawal_requests (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 method public.payment_method not null,
 amount_paisa bigint not null check (amount_paisa > 0),
 destination_account text not null,
 status public.withdrawal_status not null default 'pending',
 payout_reference text,
 admin_note text,
 reviewed_by uuid references public.profiles(id),
 reviewed_at timestamptz,
 created_at timestamptz not null default now()
);
create table public.audit_logs (
 id uuid primary key default gen_random_uuid(),
 actor_id uuid references public.profiles(id),
 action text not null,
 target_type text not null,
 target_id uuid,
 details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin') $$;

alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.payment_requests enable row level security;
alter table public.ledger enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.audit_logs enable row level security;

create policy "profile owner or admin read" on public.profiles for select using (id=auth.uid() or public.is_admin());
create policy "profile owner update basic" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid() and role = (select p.role from public.profiles p where p.id=auth.uid()));
create policy "wallet owner or admin read" on public.wallets for select using (user_id=auth.uid() or public.is_admin());
create policy "payment owner read" on public.payment_requests for select using (user_id=auth.uid() or public.is_admin());
create policy "payment owner create pending" on public.payment_requests for insert with check (user_id=auth.uid() and status='pending' and reviewed_by is null and reviewed_at is null);
create policy "withdraw owner read" on public.withdrawal_requests for select using (user_id=auth.uid() or public.is_admin());
create policy "withdraw owner request" on public.withdrawal_requests for insert with check (user_id=auth.uid() and status='pending' and reviewed_by is null and reviewed_at is null);
create policy "ledger owner read" on public.ledger for select using (user_id=auth.uid() or public.is_admin());
create policy "audit admin read" on public.audit_logs for select using (public.is_admin());

-- Intentionally no client-side UPDATE/DELETE/INSERT policies for wallets or ledger.
-- Do NOT add public policies that let users approve payments or change their role.
-- Create users' profile and wallet using a trusted server-side trigger/function after auth signup.
-- Admin review, wallet credits/debits, escrow, commission and payouts must be implemented
-- as SECURITY DEFINER RPCs or server routes with strict admin authorization, idempotency,
-- row locking and audit logging, then independently reviewed before handling money.
