 "use client";
import {useState} from "react";
import {createClient} from "@supabase/supabase-js";
export default function Login(){
 const [email,setEmail]=useState(""); const [msg,setMsg]=useState("");
 async function send(){const url=process.env.NEXT_PUBLIC_SUPABASE_URL;const key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;if(!url||!key){setMsg("প্রথমে .env.local ফাইলে Supabase URL ও anon key বসান।");return;}const sb=createClient(url,key);const {error}=await sb.auth.signInWithOtp({email,options:{emailRedirectTo:location.origin}});setMsg(error?error.message:"ইমেইলে লগইন লিংক পাঠানো হয়েছে।");}
 return <main className="login"><a href="/" className="brand">Taskora</a><h1>অ্যাকাউন্টে প্রবেশ</h1><p>ইমেইল দিয়ে নিরাপদ লগইন লিংক নিন।</p><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="আপনার ইমেইল" type="email"/><button onClick={send}>লগইন লিংক পাঠান</button><p>{msg}</p><small>ইমেইল লগইন চালুর আগে Supabase Auth কনফিগার করুন।</small></main>
}