import Link from "next/link";
export default function Home() {
  return <main>
    <nav><Link className="brand" href="/">Taskora</Link><div><a href="#how">কীভাবে কাজ করে</a><a href="#safety">নিরাপত্তা</a><Link className="navbtn" href="/login">লগইন</Link></div></nav>
    <section className="hero">
      <span className="eyebrow">MICRO JOB MARKETPLACE · BANGLADESH</span>
      <h1>ছোট কাজ, স্বচ্ছ লেনদেন,<br/><em>নতুন সুযোগ।</em></h1>
      <p>Taskora-তে ক্লায়েন্ট কাজ পোস্ট করবে, কর্মীরা কাজ জমা দেবে এবং যাচাইয়ের পর পেমেন্টের হিসাব আপডেট হবে।</p>
      <div className="actions"><Link className="primary" href="/login">শুরু করুন</Link><a className="secondary" href="#how">কীভাবে কাজ করে</a></div>
      <div className="stats"><div><b>২০%</b><span>প্ল্যাটফর্ম কমিশন*</span></div><div><b>৳ BDT</b><span>বাংলাদেশি মুদ্রা</span></div><div><b>Manual</b><span>পেমেন্ট যাচাই</span></div></div>
      <small>*কমিশনটি কর্মীর পুরস্কারের ওপর; উদাহরণ: কর্মী ৳১০০ পেলে ক্লায়েন্ট বাজেট ৳১২০।</small>
    </section>
    <section id="how" className="section"><h2>Taskora কীভাবে কাজ করে</h2><div className="cards"><article><b>01 · ক্লায়েন্ট</b><h3>কাজ পোস্ট করুন</h3><p>কাজের বিবরণ, সময়সীমা ও বাজেট নির্ধারণ করুন।</p></article><article><b>02 · কর্মী</b><h3>কাজ সম্পন্ন করুন</h3><p>যোগ্য কাজ বেছে নিয়ে নির্দেশনা অনুযায়ী জমা দিন।</p></article><article><b>03 · যাচাই</b><h3>রিভিউ ও হিসাব</h3><p>অনুমোদনের পর সার্ভার-নিয়ন্ত্রিত লেজারে হিসাব হবে।</p></article></div></section>
    <section id="safety" className="safety"><h2>নিরাপত্তা আগে</h2><p>এই প্যাকেজটি একটি MVP starter। লাইভে আসল টাকা নেওয়ার আগে পেমেন্ট প্রমাণ, অ্যাকাউন্ট, ডেটাবেস নীতি, প্রতারণা প্রতিরোধ ও আইনি অনুমোদন বিশেষজ্ঞ দিয়ে যাচাই করাতে হবে। Taskora কোনো আয় নিশ্চিত করে না।</p></section>
    <footer>© {new Date().getFullYear()} Taskora · Built for transparent work</footer>
  </main>;
}